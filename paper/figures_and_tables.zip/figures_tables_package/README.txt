FIGURES AND TABLES
Paper: TurboQuant in the Browser: A Feasibility Study of KV-Cache Compression for Gemma 4 on Chrome WebGPU
Authors: Dhonam Pemba, Kwang Wei Sim (Stratos Lab)
Date: 2026-04-05

FIGURES (figures/)
==================
speed_quality_frontier.png   Fig 1 – Speed-quality frontier scatter (all 15 config-case pairs)
heatmap_compression_ratio.png  Fig 2 – Compression ratio heatmap (case × config)
heatmap_prefix_agreement.png   Fig 3 – Prefix agreement heatmap (case × config)
heatmap_speed_ratio.png        Fig 4 – Speed ratio heatmap (case × config)
latency_bars.png               Fig 5 – Absolute generation latency bars (ms)
ttft_tps_bars.png              Fig 6 – Time-to-first-token and decode throughput bars

All figures generated from turboquant-benchmark.json (see supplementary materials).
All figures are 150 DPI PNG.

TABLES (tables/)
================
config_summary.csv   Table 1 – Aggregate metrics by TurboQuant configuration
benchmark_rows.csv   Table 2 / raw data – Per-case, per-configuration results
case_summary.csv     Summary view – per-case best metrics across configs

COLUMN DEFINITIONS (benchmark_rows.csv)
========================================
case_id, case_label, case_description    – Prompt case identifier and description
max_new_tokens                           – Maximum output tokens budget
config_id, config_label                  – TurboQuant configuration identifier
b_key, b_value, residual_length          – Quantiser parameters
dynamic_avg_ms                           – Dense baseline average latency (ms)
dynamic_ttft_ms                          – Dense baseline TTFT (ms)
dynamic_tps                              – Dense baseline decode throughput (tokens/s)
dynamic_packed_bytes / dynamic_dense_bytes – Cache byte counts (dense path)
turbo_avg_ms                             – TurboQuant average latency (ms)
turbo_ttft_ms                            – TurboQuant TTFT (ms)
turbo_tps                                – TurboQuant decode throughput (tokens/s)
turbo_packed_bytes / turbo_dense_bytes   – Cache byte counts (TurboQuant path)
speed_ratio                              – dynamic_avg_ms / turbo_avg_ms
compression_ratio                        – dynamic_dense_bytes / turbo_packed_bytes
prefix_agreement_ratio                   – LCP(dense_output, turbo_output) / len(dense_output)
prefix_agreement_pct                     – prefix_agreement_ratio * 100
exact_match                              – 1 if outputs are identical, 0 otherwise
