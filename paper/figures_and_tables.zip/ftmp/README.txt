Figures and Tables — TurboQuant in the Browser
===============================================

Source benchmark: Chrome Benchmarkv2.txt (latest run)
Generated from: gen_assets_v2.py

figures/
  speed_quality_frontier.png  – Fig 1: speed ratio vs prefix agreement scatter
  heatmap_compression_ratio.png – Fig 2: compression ratio heatmap
  heatmap_prefix_agreement.png  – Fig 3: prefix agreement heatmap
  heatmap_speed_ratio.png       – Fig 4: speed ratio heatmap
  latency_bars.png              – Fig 5: end-to-end latency bar chart
  ttft_tps_bars.png             – Fig 6: TTFT and TPS side-by-side bars

tables/
  benchmark_rows.csv   – one row per (case, config); columns: case, cache_mb, config,
                          dynamic_avg_ms, turbo_avg_ms, speed_ratio, compression_ratio,
                          prefix_agreement, exact_match, ttft_ms, turbo_tps
  config_summary.csv   – aggregate by config: avg_speed_ratio, avg_compression,
                          avg_prefix_agreement, avg_tps, exact_count, n_cases
  case_summary.csv     – best per case: best_speed_ratio, best_compression,
                          best_prefix_agreement and the config that achieved them

All speed ratios: dynamic_avg_ms / turbo_avg_ms (>1 = turbo faster)
All compression ratios: dense_bytes / packed_bytes (>1 = genuine compression)
Prefix agreement: LCP(dense_output, turbo_output) / max(len(dense_output), 1)
