# Reproducing the TurboQuant Browser Benchmark

## Requirements
- Chrome or Chromium with WebGPU enabled
- The stratoslab/transformers.js fork (see §5.4 of manuscript for commit hashes)
- The benchmark harness application (commit 7af609f)

## Steps

1. Clone the fork:
   ```
   git clone https://github.com/stratoslab/transformers.js
   cd transformers.js
   git checkout <latest relevant commit>
   npm install && npm run build
   ```

2. Open the benchmark harness in Chrome with WebGPU enabled:
   ```
   chromium --enable-unsafe-webgpu <path-to-harness>/index.html?benchmark=1
   ```

3. Click "Load Model" and wait for `onnx-community/gemma-4-E2B-it-ONNX` (q4f16) to load.

4. Click "Run Suite". The harness will sweep all 3 TurboQuant configurations
   across all 5 prompt cases, running 2 trials each.

5. Click "Export JSON" to save the raw benchmark data.

## Notes
- Hardware GPU model was not systematically recorded; absolute latency figures
  will vary by adapter. Speed ratios and compression ratios should be more stable.
- The benchmark data in this package (`Chrome Benchmarkv2.txt`) was captured
  from a single Chrome WebGPU session on a single machine.
- A minimum of 5–10 runs per configuration is recommended for statistical robustness;
  the current data uses n=2.

## Benchmark columns (benchmark_rows.csv)
| Column | Description |
|---|---|
| case | Prompt case label |
| cache_mb | Approximate dense KV-cache size in MB |
| config | TurboQuant configuration name |
| dynamic_avg_ms | Mean end-to-end latency for dense baseline (ms) |
| turbo_avg_ms | Mean end-to-end latency for TurboQuant (ms) |
| speed_ratio | dynamic_avg_ms / turbo_avg_ms (>1 = turbo faster) |
| compression_ratio | dense_bytes / packed_bytes (>1 = genuine compression) |
| prefix_agreement | Fraction of dense output matched character-for-character |
| exact_match | 1 if outputs are identical, 0 otherwise |
| ttft_ms | Time-to-first-token for the TurboQuant run (ms) |
| turbo_tps | Decode throughput for the TurboQuant run (tok/s) |
