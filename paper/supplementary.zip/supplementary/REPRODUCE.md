# Benchmark Reproduction Instructions

## Paper
TurboQuant in the Browser: A Feasibility Study of KV-Cache Compression for Gemma 4 on Chrome WebGPU
Dhonam Pemba, Kwang Wei Sim — Stratos Lab (2026)

## What is in this supplementary package

| File | Description |
|---|---|
| turboquant-benchmark.json | Full benchmark export from the browser harness |
| benchmark_rows.csv | Derived row-level results (one row per case × config) |
| config_summary.csv | Derived aggregate results by configuration |
| case_summary.csv | Derived per-case best results |
| implementation-methods.md | Implementation notes for the transformers.js fork |
| REPRODUCE.md | This file |

## Software requirements

- Chrome (tested on Chrome WebGPU with a discrete GPU)
- Node.js ≥ 18 (for building the fork)
- Git

## Step 1 — Clone and build the fork

```bash
git clone https://github.com/stratoslab/transformers.js
cd transformers.js
npm install
npm run build
```

Relevant implementation commits in the fork:
- db06d73  Add pluggable generation cache and TurboQuant scaffold
- 4fab2e0  Pack TurboQuant cache tensors into low-bit storage
- 24c4c0b  Add rotation and residual correction to TurboQuant cache
- dfbf815  Add TurboQuant cache stats and unit tests
- 0424f44  Expose cache stats from generate()
- fa534d7  Add TurboQuant benchmark script and docs
- 3e268cc  Improve TurboQuant reconstruction and benchmark output
- 0b2b2d6  Fix DynamicCache base constructor
- 529939a  Fix GPU-safe cache stats and benchmark harness
- 337eb60  Tune TurboQuant defaults with dense residual window

## Step 2 — Clone and build the benchmark app

The benchmark app is a separate repository. App-side commit: 7af609f

```bash
# Clone the app repository (see paper for repo URL)
git clone <app-repo-url>
cd <app-repo>
# Point the app to your local transformers.js build (see vite.config.js)
npm install
npm run dev
```

## Step 3 — Run the benchmark

1. Open Chrome and navigate to the local dev server (default: http://localhost:5173)
2. Click "Load Model" — this downloads onnx-community/gemma-4-E2B-it-ONNX (q4f16) from Hugging Face
3. Click "Run Suite" — this runs all 5 cases × (1 dynamic + 3 TurboQuant configs) × 2 runs
4. Click "Export JSON" — this saves the benchmark results JSON

## Model information

- Model ID: onnx-community/gemma-4-E2B-it-ONNX
- Model dtype: q4f16
- Source: https://huggingface.co/onnx-community/gemma-4-E2B-it-ONNX

## Benchmark cases and configurations

### Cases
| ID | Label | Max new tokens |
|---|---|---|
| risk-short | Risk Summary | 48 |
| ops-checklist | Operations Checklist | 72 |
| policy-compare | Policy Comparison | 80 |
| long-context-1k | Long Context 1x | 96 |
| long-context-2k | Long Context 2x | 96 |

### TurboQuant configurations
| Config | b_key | b_value | residual_length |
|---|---|---|---|
| safe-default | 4 | 8 | 64 |
| mid-compression | 4 | 8 | 48 |
| key-heavy | 3 | 8 | 64 |

## Hardware note

The benchmark hardware was not systematically recorded. Absolute timing numbers
(ms, tokens/s) depend on the GPU adapter. Relative metrics (speed ratios,
compression ratios) should be more portable across hardware.

## Data format (turboquant-benchmark.json)

Top-level fields:
- modelId: "onnx-community/gemma-4-E2B-it-ONNX"
- runs: 2 (runs per configuration)
- cases: array of case definitions
- results: array of result objects, each containing:
  - case: case metadata
  - dynamic: baseline dense-cache results (timings, outputs, cache stats)
  - sweepResults: array of TurboQuant config results
